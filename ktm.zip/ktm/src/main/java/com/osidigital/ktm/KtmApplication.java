package com.osidigital.ktm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtmApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtmApplication.class, args);
	}

}
