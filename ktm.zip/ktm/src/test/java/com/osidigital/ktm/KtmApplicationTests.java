package com.osidigital.ktm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KtmApplicationTests {

	@Test
	void contextLoads() {
	}

}
